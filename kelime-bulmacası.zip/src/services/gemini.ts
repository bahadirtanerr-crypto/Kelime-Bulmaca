import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface PuzzleData {
  word: string;
  hint: string;
  category: string;
}

export async function generatePuzzle(difficulty: 'easy' | 'medium' | 'hard' = 'medium'): Promise<PuzzleData> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Bana ${difficulty} zorluk seviyesinde bir Türkçe kelime bulmacası üret. Kelime tek bir kelime olmalı.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          word: {
            type: Type.STRING,
            description: "Bulunacak kelime (Büyük harf, Türkçe karakterlere uygun)",
          },
          hint: {
            type: Type.STRING,
            description: "Kelime için ipucu veya tanım",
          },
          category: {
            type: Type.STRING,
            description: "Kelimenin kategorisi (örn: Hayvanlar, Teknoloji, Mutfak)",
          },
        },
        required: ["word", "hint", "category"],
      },
    },
  });

  try {
    const data = JSON.parse(response.text || "{}");
    return {
      word: data.word.toUpperCase().trim(),
      hint: data.hint,
      category: data.category,
    };
  } catch (error) {
    console.error("Puzzle generation failed:", error);
    return {
      word: "ELMA",
      hint: "Kırmızı veya yeşil renkli, kütür kütür bir meyve.",
      category: "Meyveler",
    };
  }
}
